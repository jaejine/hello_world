package com.yedam.classes;

public class MethodExe3 {
	
	// 구구단출력.
//	String gugudan(int num , int toNum) {
//		
//		String str = "";
//		for(int n=num; n<=toNum; n++){
//			int dan = n;
//			for(int i=1; i<=9; i++) {
//				str += dan + " * " + i + " = " + (dan*i) + "\n";
//				
//				
//			}
//		}
//		return str;
//	} // end of gugudan.
	
	void printStar(int cnt, String str) {
		String star = "";
		for(int i=1; i<=cnt; i++) {
			star += str;
			System.out.println(star);
		}
	}
	
	void prinSter(int cnt, String str) {
		String star = " ";
		for(int i=1; i<=cnt; i++) {
			for(int j=1; j<=; j++)
		}
	}
	
	
}
