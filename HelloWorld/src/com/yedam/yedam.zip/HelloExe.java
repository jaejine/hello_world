package com.yedam;

public class HelloExe {
	// 기능(함수) => main 이라고 하는 메소드.
	public static void main(String[] args) {
		System.out.println("Hello, World");
		
		String name; // 문자 데이터 타입 String
		name = "심재진";
		
		System.out.println("이름은 : " + name);
		
		int score = 100; // 정수 데이터타입 int
		
		System.out.println("점수는 : " + score + "점 입니다.");
		System.out.println("수정된 부분");
	}
}