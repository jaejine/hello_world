package com.yedam.variable;

public class VarExe8 {
	public static void main(String[] args) {
//		int n1 = 10;
//		byte b1 = 120;
//		byte result = (byte) (b1 + 130); // -128 ~ 127 )) (byte) -> 큰 범위의 값을 작은 범위의 값으로 변환 형변환(casting)
//		System.out.println("더한 결과 : " + result); // 127 이 넘으면 -128 , -127 , -126 순으로 다시돌아감
//		n1 = b1;
//		System.out.println(n1);
//		n1 = 200;
//		b1 = (byte) n1;
//		System.out.println(b1);
//		
        int first = 472;
        int last = 385;
        System.out.println(5*first);
        System.out.println(8*first);
        System.out.println(3*first);
        System.out.println(first*last);
		
//		for(int i=1; i<15; i++) {
//			System.out.println(b1++);
//			// byte -> int ( 자동형변환 : promotion ) 

//		}
	}
}
